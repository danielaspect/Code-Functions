const showPopup = document.querySelector('.show-popup');
const popupContainer = document.querySelector('.popup-container');
const closeBtn = document.querySelector('.close-btn');
const unlockCheckboxes = document.querySelectorAll('.unlock-checkbox');
const yearInputs = document.querySelectorAll('.year-input');

showPopup.onclick = () => {
    popupContainer.classList.add('active');
};

closeBtn.onclick = () => {
    popupContainer.classList.remove('active');
};

unlockCheckboxes.forEach((checkbox) => {
    checkbox.addEventListener('change', () => {
        const targetInputId = checkbox.dataset.input;
        const partnerCheckboxId = checkbox.dataset.pair;
        const activePairGroup = checkbox.dataset.pairGroup;

        if (checkbox.checked) {
            // Auto-check partner if it exists
            if (partnerCheckboxId) {
                const partnerCheckbox = document.getElementById(partnerCheckboxId);
                if (partnerCheckbox) {
                    partnerCheckbox.checked = true;
                }
            }

            // Disable all checkboxes NOT in the active pair group
            unlockCheckboxes.forEach((otherCheckbox) => {
                const otherPairGroup = otherCheckbox.dataset.pairGroup;
                if (otherPairGroup !== activePairGroup) {
                    otherCheckbox.disabled = true;
                    otherCheckbox.checked = false;
                }
            });

            // Lock all inputs except the ones for the checked boxes in this pair
            yearInputs.forEach((input) => {
                const inputBelongsToActivePair = 
                    input.id === targetInputId || 
                    (partnerCheckboxId && input.id === document.getElementById(partnerCheckboxId).dataset.input);
                input.disabled = !inputBelongsToActivePair;
            });
        } else {
            // Check if ANY checkbox in the active pair is still checked
            const pairGroupCheckboxes = Array.from(unlockCheckboxes).filter(
                cb => cb.dataset.pairGroup === activePairGroup
            );
            const anyInPairChecked = pairGroupCheckboxes.some(cb => cb.checked);

            if (!anyInPairChecked) {
                // Re-enable all checkboxes
                unlockCheckboxes.forEach((otherCheckbox) => {
                    otherCheckbox.disabled = false;
                });

                // Enable all inputs
                yearInputs.forEach((input) => {
                    input.disabled = false;
                });

                // Uncheck partner if it exists
                if (partnerCheckboxId) {
                    const partnerCheckbox = document.getElementById(partnerCheckboxId);
                    if (partnerCheckbox) partnerCheckbox.checked = false;
                }
            }
        }
    });
});