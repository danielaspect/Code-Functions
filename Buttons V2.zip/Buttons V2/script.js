// Database mapping main selections to their corresponding horizontal button options
const subCategories = {
    certified: [
        "Certified True Copy of Birth",
        "Certified True Copy of Marriage",
        "Certified True Copy of Death",
        "Release of Triplicate Copy",
        "Release of Marriage License"
    ],
    reports: [
        "Supplemental Report", 
        "RA 9255 - AUSF",
        "Court Decree"
    ],
    registration: [
        "New Profile Entry", 
        "Identity Credentials Check"
    ],
    acknowledgement: [
        "Notarized Declarations", 
        "Oaths Register"
    ],
    corrections: [
        "Typo Adjustments", 
        "Structural Record Amendment"
    ]
};

// Select target interface nodes
const dropdown = document.getElementById('mainCategoryDropdown');
const container = document.getElementById('subCategoryContainer');

// ==========================================================================
// 1. GENERATING THE SUB-CATEGORY BUTTONS
// ==========================================================================
dropdown.addEventListener('change', (event) => {
    const selectedValue = event.target.value;
    
    // Clear out old buttons and reset table visibility
    container.innerHTML = "";
    resetTableFilters();

    if (subCategories[selectedValue]) {
        subCategories[selectedValue].forEach(subName => {
            
            // Create the button element
            const buttonElement = document.createElement('button');
            buttonElement.classList.add('sub-chip-btn');
            buttonElement.textContent = subName;

            // Trigger the filter function when clicked
            buttonElement.addEventListener('click', () => {
                filterTableByTransaction(subName);
                
                // 1. Remove '.is-active' class from ALL sub-buttons
                document.querySelectorAll('.sub-chip-btn').forEach(btn => {
                    btn.classList.remove('is-active');
                });
                
                // 2. Add '.is-active' ONLY to the button that was just clicked
                buttonElement.classList.add('is-active');
            });

            container.appendChild(buttonElement);
        });
    }
});

// ==========================================================================
// 2. THE FILTERING LOGIC (How it reads and hides rows)
// ==========================================================================
function filterTableByTransaction(transactionType) {
    // Grab all rows inside the table body (excluding the header)
    const tableRows = document.querySelectorAll('tbody tr');

    tableRows.forEach(row => {
        // Grab the text inside the 5th column (Index 4: "Transaction" column)
        const transactionCellText = row.children[4].textContent.trim();

        // Compare the text. If it matches, show it. If not, hide it!
        if (transactionCellText === transactionType) {
            row.style.display = ""; // Shows the row normally
        } else {
            row.style.display = "none"; // Hides the row completely from view
        }
    });
}

// Helper function to show all rows again if the user resets the dropdown
function resetTableFilters() {
    const tableRows = document.querySelectorAll('tbody tr');
    tableRows.forEach(row => {
        row.style.display = ""; 
    });
}