// Database mapping main selections to their corresponding horizontal button options
const subCategories = {
    certified: [
        "Certified True Copy of Birth",
        "Certified True Copy of Marriage",
        "Certified True Copy of Death",
        "Release of Triplicate Copy",
        "Release of Marriage License"
    ],
    reports: [
        "Supplemental Report", 
        "Administrative Endorsements"
    ],
    registration: [
        "New Profile Entry", 
        "Identity Credentials Check"
    ],
    acknowledgement: [
        "Notarized Declarations", 
        "Oaths Register"
    ],
    corrections: [
        "Typo Adjustments", 
        "Structural Record Amendment"
    ]
};

// Select target interface nodes
const dropdown = document.getElementById('mainCategoryDropdown');
const container = document.getElementById('subCategoryContainer');

// Event listener: Watch for dropdown selection adjustments
dropdown.addEventListener('change', (event) => {
    const selectedValue = event.target.value;
    
    // Clear out any sub-buttons already rendered on screen
    container.innerHTML = "";

    // If data arrays exist for selected value, build button elements
    if (subCategories[selectedValue]) {
        subCategories[selectedValue].forEach(subName => {
            
            // Create a native HTML button node
            const buttonElement = document.createElement('button');
            buttonElement.classList.add('sub-chip-btn');
            buttonElement.textContent = subName;

            // Optional: Give it an action when clicked
            buttonElement.addEventListener('click', () => {
                alert(`Filtering table data by: ${subName}`);
                // Your sorting/filtering processing function goes here!
            });

            // Append the finished button element onto our tracking row layout
            container.appendChild(buttonElement);
        });
    }
});