// A database containing the content details for each button click
const modalContent = {
    certified: {
        title: "Certified True Copy",
        text: "Requesting an official duplicate of a document that is formally verified to match the master original perfectly."
    },
    reports: {
        title: "Reports & Endorsements",
        text: "Access formal, official documentation and administrative approval logs relevant to your filed accounts."
    },
    registration: {
        title: "Registration Portal",
        text: "Initialize a new profile file, enter identity credentials, and log official data into the central register."
    },
    acknowledgement: {
        title: "Acknowledgement & Affidavits",
        text: "Review and legally sign notarized written statements and confirmations made under oath."
    },
    corrections: {
        title: "Data Corrections",
        text: "Submit formal amendment claims to alter historical data entry mistakes or fix structural typos."
    }
};

// Select the HTML elements we need to control
const buttons = document.querySelectorAll('.pill-button');
const overlay = document.getElementById('modalOverlay');
const modalTitle = document.getElementById('modalTitle');
const modalBody = document.getElementById('modalBody');
const closeBtn = document.getElementById('closeModal');

// Function: Open Modal & Inject correct content
buttons.forEach(btn => {
    btn.addEventListener('click', () => {
        const targetKey = btn.getAttribute('data-target'); // Find out which button was clicked
        const content = modalContent[targetKey];           // Pull content from database
        
        if (content) {
            modalTitle.textContent = content.title;        // Update title
            modalBody.textContent = content.text;          // Update body description
            overlay.classList.add('is-active');            // Fade modal into view
        }
    });
});

// Function: Close Modal
function hideModal() {
    overlay.classList.remove('is-active');
}

// Trigger close functions via Close Button OR Clicking the dark background overlay
closeBtn.addEventListener('click', hideModal);
overlay.addEventListener('click', (event) => {
    // Only close if the user clicked the actual dark overlay background, not the white box
    if (event.target === overlay) {
        hideModal();
    }
});